#ifndef CRC8_H
#define CRC8_H

#define CRC8_INIT   0xFF
#define CRC8_OK     0x00

#endif
