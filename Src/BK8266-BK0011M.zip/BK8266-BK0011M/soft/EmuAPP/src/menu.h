#ifndef MENU_H
#define MENU_H

#define MENU_FLAG_START_UI  0x01
#define MENU_FLAG_LOAD_FILE 0x02

#endif
