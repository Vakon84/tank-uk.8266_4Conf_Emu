#ifndef KEY_EU_H_INCLUDE
#define KEY_EU_H_INCLUDE

#include <stdint.h>

uint_fast16_t Key_Translate (uint_fast16_t CodeAndFlags);

#endif
