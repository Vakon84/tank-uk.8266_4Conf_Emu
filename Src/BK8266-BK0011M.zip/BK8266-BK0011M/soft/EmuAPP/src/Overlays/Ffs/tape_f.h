#ifndef TAPE_F_H
#define TAPE_F_H

void tape_ReadOp  (void);
void tape_WriteOp (void);

#endif
