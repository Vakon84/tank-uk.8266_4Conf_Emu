#ifndef EMU_E_H
#define EMU_E_H

void emu_start (void);

#endif
