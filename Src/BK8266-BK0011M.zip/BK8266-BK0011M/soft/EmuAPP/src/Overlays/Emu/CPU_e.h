#ifndef CPU_E_H_INCLUDE
#define CPU_E_H_INCLUDE

void CPU_RunInstruction (void);
void CPU_Stop           (void);

#endif
