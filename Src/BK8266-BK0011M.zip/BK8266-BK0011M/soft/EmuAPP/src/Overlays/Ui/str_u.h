#ifndef STR_U_H
#define STR_U_H

int str_nlen (const char *s, int maxlen);

#endif
