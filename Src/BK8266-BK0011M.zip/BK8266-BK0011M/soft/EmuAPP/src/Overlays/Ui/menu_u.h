#ifndef MENU_U_H
#define MENU_U_H

#include <stdint.h>

int_fast16_t menu_fileman (uint_fast8_t Flags);
void         menu         (uint_fast8_t Flags);

#endif
