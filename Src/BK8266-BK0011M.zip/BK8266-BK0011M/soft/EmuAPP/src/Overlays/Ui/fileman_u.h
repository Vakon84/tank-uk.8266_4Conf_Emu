#ifndef FILEMAN_U_H
#define FILEMAN_U_H

#include <stdint.h>

int_fast16_t fileman (uint8_t type, uint_fast8_t Mode);

#endif
