#ifndef CRC8_FU_H
#define CRC8_FU_H

#include <stdint.h>

uint8_t CRC8 (uint8_t crc, const uint8_t *data, uint8_t len);

#endif
