#ifndef STR_FU_H
#define STR_FU_H

int to_upper (int c);

#endif
