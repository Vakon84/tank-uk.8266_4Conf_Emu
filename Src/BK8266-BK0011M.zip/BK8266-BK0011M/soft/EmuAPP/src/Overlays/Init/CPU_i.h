#ifndef CPU_I_H_INCLUDE
#define CPU_I_H_INCLUDE

void CPU_Init (void);

#endif
