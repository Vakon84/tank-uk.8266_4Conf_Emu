#ifndef TV_I_H
#define TV_I_H

void tv_init  (void);
void tv_start (void);

#endif
