#ifndef PS2_I_H
#define PS2_I_H

void ps2_init (void);

#endif
