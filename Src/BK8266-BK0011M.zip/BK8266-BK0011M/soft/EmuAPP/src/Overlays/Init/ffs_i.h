#ifndef FFS_I_H
#define FFS_I_H

#include <stdint.h>

void ffs_init (void);

#endif
