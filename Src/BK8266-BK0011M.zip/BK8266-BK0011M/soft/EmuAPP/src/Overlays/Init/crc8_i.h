#ifndef CRC8_I_H
#define CRC8_I_H

#include <stdint.h>

uint8_t CRC8_i (uint8_t crc, const uint8_t *data, uint8_t len);

#endif
