#ifndef I2S_I_H
#define I2S_I_H

#include "i2s.h"

void i2s_init  (int size);
void i2s_start (void);

#endif

