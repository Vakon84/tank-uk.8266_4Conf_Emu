#ifndef MAIN_I_H
#define MAIN_I_H

void main_init (void);

#endif
