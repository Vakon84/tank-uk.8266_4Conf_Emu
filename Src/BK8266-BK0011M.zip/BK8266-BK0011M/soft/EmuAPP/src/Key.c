#include <stdint.h>
#include "Key.h"

uint32_t Key_Flags;
