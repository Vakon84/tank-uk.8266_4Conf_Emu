#ifndef REBOOT_H
#define REBOOT_H


#include <c_types.h>


#ifdef __cplusplus
extern "C" {
#endif


void reboot(uint32_t value);


#ifdef __cplusplus
}
#endif


#endif
