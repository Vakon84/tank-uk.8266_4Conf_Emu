#ifndef SPI_FLASH_H_INCLUDE
#define SPI_FLASH_H_INCLUDE

#include <inttypes.h>
#include "ets.h"

uint32_t spi_flash_unlock (void);

#endif
